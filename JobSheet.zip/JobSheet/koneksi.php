<?php 
$koneksi = mysqli_connect("localhost","id12707471_db_sekolah","db_sekolah","db_sekolah");

// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}

?>