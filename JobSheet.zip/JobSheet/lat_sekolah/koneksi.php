<?php
$koneksi = mysqli_connect (
    "localhost","id12707471_db_sekolah","db_sekolah","db_sekolah"
);
if (!$koneksi){
    die("Gagal terhubung dengan database: " . mysqli_connect_error());
}
?>